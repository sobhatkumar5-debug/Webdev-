document.addEventListener('DOMContentLoaded', () => {
    console.log('Accessible portfolio website loaded successfully.');
});