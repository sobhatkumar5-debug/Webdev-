const todoInput = document.getElementById('todo-input');
const addBtn = document.getElementById('add-btn');
const todoList = document.getElementById('todo-list');
const filterButtons = document.querySelectorAll('.filter-btn');

let todos = JSON.parse(localStorage.getItem('todos')) || [];
let currentFilter = 'all';

function saveTodos() {
  localStorage.setItem('todos', JSON.stringify(todos));
}

function renderTodos() {

  todoList.innerHTML = '';

  let filteredTodos = todos.filter(todo => {

    if (currentFilter === 'active') return !todo.completed;
    if (currentFilter === 'completed') return todo.completed;

    return true;
  });

  filteredTodos.forEach(todo => {

    const li = document.createElement('li');
    li.className = `todo-item ${todo.completed ? 'completed' : ''}`;
    li.dataset.id = todo.id;

    li.innerHTML = `
      <span class="task-text">${todo.text}</span>

      <div class="task-actions">

        <button class="complete-btn">
          ${todo.completed ? 'Undo' : 'Complete'}
        </button>

        <button class="edit-btn">Edit</button>

        <button class="delete-btn">Delete</button>

      </div>
    `;

    todoList.appendChild(li);
  });

}

function addTodo() {

  const text = todoInput.value.trim();

  if (!text) return;

  const todo = {
    id: Date.now(),
    text,
    completed: false
  };

  todos.push(todo);

  saveTodos();
  renderTodos();

  todoInput.value = '';
}

addBtn.addEventListener('click', addTodo);

todoInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    addTodo();
  }
});

todoList.addEventListener('click', (e) => {

  const li = e.target.closest('.todo-item');

  if (!li) return;

  const id = Number(li.dataset.id);

  const todo = todos.find(todo => todo.id === id);

  if (e.target.classList.contains('complete-btn')) {

    todo.completed = !todo.completed;

  }

  if (e.target.classList.contains('delete-btn')) {

    todos = todos.filter(todo => todo.id !== id);

  }

  if (e.target.classList.contains('edit-btn')) {

    const newText = prompt('Edit your task:', todo.text);

    if (newText !== null && newText.trim() !== '') {
      todo.text = newText.trim();
    }

  }

  saveTodos();
  renderTodos();

});

filterButtons.forEach(button => {

  button.addEventListener('click', () => {

    filterButtons.forEach(btn => btn.classList.remove('active'));

    button.classList.add('active');

    currentFilter = button.dataset.filter;

    renderTodos();

  });

});

renderTodos();
